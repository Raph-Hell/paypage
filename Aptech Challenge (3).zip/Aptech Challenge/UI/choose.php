<?php
require_once ('db/config.php');

session_start();
if(!isset($_SESSION['email'])){
    header('location: pay-page.php');
}
?>

<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport"
              content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Payment Page</title>
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/animate.min.css">
        <link rel="shortcut icon" href="img/omega-logo-black-and-white.png" type="image/x-icon">
        <script defer src="js/choose.js"></script>
        <script src="js/sweetalert.min.js"></script>
        <style>
            .style{
                color:#fff; 
                font-size: .9rem; 
                text-decoration:underline;
                transition: all .5s ease-in-out;
            }
            .style:hover{
                color: #00f;
            }
        </style>
    </head>

    <body>
        <?php
            include ('alerts.php');
        ?>
        <div class="wrapper">
            <div class="row animate__animated animate__zoomIn">

                <!--  The Circle Thingy    -->
                <div class="rounded">
                    <div class="inner">
                        <div class="inner-inner">
                        </div>
                    </div>
                </div>

                <div class="rounded second">
                    <div class="inner">
                        <div class="inner-inner">
                        </div>
                    </div>
                </div>

                <div class="rounded big">
                    <div class="inner">
                        <div class="inner-inner">
                        </div>
                    </div>
                </div>

                <!-- /end of The Circle            -->
                <div class="col-7">
                    <h1 id="main">Choose Payment Method</h1>
                    <form class="form-container" action="handler/handler.php" method="post">
                        <div class="pay-btn">
                            <a id="stripe" class="btn" style="display:flex; justify-content:center; align-items:center;">
                                <span>Strip</span>
                                <img src="img/Stripe%20wordmark%20-%20slate.svg" style="width: 28px; border-radius: 50%; height: 28px; margin-left: 8px;">
                            </a>
                        </div>
                        <div class="pay-btn">
                            <a href="handler/handler.php?p_m=paystack" class="btn" style="display:flex; justify-content:center; align-items:center;">
                                <span>PayStack</span>
                                <img src="img/d06dd1bc44667e9d71d859f768712b7c.webp" style="width: 28px; border-radius: 50%; height: 28px; margin-left: 8px;">
                            </a>
                        </div>
                        <div class="pay-btn">
                            <a id="paypal" class="btn" style="display:flex; justify-content:center; align-items:center;">
                                <span>PayPal</span>
                                <img src="img/paypal.svg" style="width: 28px; border-radius: 50%; height: 28px; margin-left: 8px;">
                            </a>
                        </div>
                        <p style="margin: 8px 0 0 0;"><a class="style" href="handler/handler.php?cancel">Cancel </a></p>
                    </form>
                </div>
                <div class="col-5">
                    <div class="img-container">
                        <img src="img/1606372760245.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>