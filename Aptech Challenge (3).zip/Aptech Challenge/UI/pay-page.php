<?php
require_once ('db/config.php');

session_start();
if(isset($_SESSION['email'])){
    header('location: choose.php');
}
?>

<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport"
              content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Payment Page</title>
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/animate.min.css">
        <script defer src="js/main.js"></script>
        <script src="js/sweetalert.min.js"></script>
    </head>

    <body>
    <?php
        include ('alerts.php');
    ?>
        <div class="wrapper">
            <div class="row animate__animated animate__zoomIn">

                    <!--  The Circle Thingy    -->
                <div class="rounded">
                    <div class="inner">
                        <div class="inner-inner">
                        </div>
                    </div>
                </div>

                <div class="rounded second">
                    <div class="inner">
                        <div class="inner-inner">
                        </div>
                    </div>
                </div>

                <div class="rounded big">
                    <div class="inner">
                        <div class="inner-inner">
                        </div>
                    </div>
                </div>

                    <!-- /End of The Circle            -->
                <div class="col-7">
                    <h1 id="main">Aptech Course Payment</h1>
                    <form class="form-container" action="handler/handler.php" method="post">
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label>Course</label>
                            <div class="form-control" id="coursediv">
                                <span id="course" name="course"></span>
                                <span class="trigger">&blacktriangledown;</span>
                                <input type="hidden" name="course" id="mainCourse">

                                <!--       The <Select> Replica      -->
                                <ul class="list">
                                    <?php

                                        //Getting Courses & Price from the DB
                                        $result = $connect->query("SELECT * FROM course");
                                        $result->execute();

                                        while ($row = $result->fetch(PDO::FETCH_ASSOC)){
                                            ?>
                                                <li class="list-item" id="<?php echo number_format($row['price']); ?>">
                                                    <?php echo $row['course_name']; ?>
                                                </li>
                                            <?php
                                        }
                                    ?>

                                </ul>
                                <!--       The <Select> Replica        -->
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Price</label>
                            <input type="text" readonly name="price" id="price">
                        </div>

                        <div class="form-group">
                            <button name="submit" type="submit" class="btn btn-primary border">Pay</button>
                        </div>
                    </form>
                </div>
                <div class="col-5">
                    <div class="img-container">
                        <img src="img/1606372099247.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>