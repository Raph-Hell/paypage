const h1 = document.querySelector('#static');

window.addEventListener('scroll', ()=>{
    if(window.pageYOffset > 90){
        h1.classList.add('dark');
    }
    else{
        h1.classList.remove('dark');
    }
});
