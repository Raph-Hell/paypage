function selector(name){
    return document.querySelector(name);
}
function selectors(name){
    return document.querySelectorAll(name);
}

const price = selector('#price');
const select = selectors('.list-item');
const selectBox = selector('#course');
const trigger = selector('.trigger');
const list = selector('.list');
const mainCourse = selector('#mainCourse');

let state = false;

select.forEach(val =>{
    val.addEventListener('click', ()=>{
        selectBox.innerHTML = val.textContent;
        mainCourse.value = val.textContent;
        list.style.display = 'none';
        state = !state;
        price.value = `N${val.getAttribute('id')}`;
        price.style.color = '#ccc';
    })
});

trigger.addEventListener('click', ()=>{
    state = !state;
    if (state){
        list.style.display = 'block';
    }else{
        list.style.display = 'none';
    }
})
