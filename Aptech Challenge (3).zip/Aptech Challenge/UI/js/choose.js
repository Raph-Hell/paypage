const paypal = document.querySelector('#paypal');
const stripe = document.querySelector('#stripe');

paypal.style.cursor = 'not-allowed';
stripe.style.cursor = 'not-allowed';