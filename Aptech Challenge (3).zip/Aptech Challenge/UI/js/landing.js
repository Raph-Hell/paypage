function selector(name){
    return document.querySelector(name);
}
const landing = selector('.landing-page');
const lift = selector('#lift');
const span = selector('.span');
const notifier = selector('.notifier');

lift.addEventListener('click', ()=>{
    landing.classList.add('wrap');
    span.style.animationName = 'trans';

    setTimeout(()=>{
        window.open('../UI/pay-page.php', '_self');
    }, 1000);
})

setTimeout(()=>{
    notifier.style.bottom = '0';
}, 500)