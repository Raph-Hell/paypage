<?php
    if(isset($_GET['alert'])){
        switch ($_GET['alert']){
            case 'exists':
                ?>
                <script>
                    swal("You've Paid for the Course Already!", '', 'error');
                </script>
                <?php
                break;

            case 'del_s':
                ?>
                <script>
                    swal("Transaction Deleted", '', 'success');
                </script>
                <?php
                break;

            case 'p_s':
                ?>
                <script>
                    swal("Transaction Completed", '', 'success');
                </script>
                <?php
                break;

            case 'cancelled':
                ?>
                <script>
                    swal("Transaction Cancelled", '', 'success');
                </script>
                <?php
                break;
        }
    }