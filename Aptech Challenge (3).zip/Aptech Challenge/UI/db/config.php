<?php
define('HOST', 'localhost');
define('USER', 'root');
define('PASSWORD', '');
define('DB_NAME', 'portal');

/** CONNECTING TO THE DATABASE **/
$dsn = "mysql:dbhost=". HOST . ";dbname=" . DB_NAME;
$connect = new PDO($dsn, USER, PASSWORD);