<?php
require_once ('db/config.php');

?>

<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport"
              content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Payment Page</title>
        <link rel="stylesheet" href="css/transact.css">
        <script src="js/sweetalert.min.js"></script>
    </head>
    <body>
        <?php
            include ('alerts.php');
        ?>
        <div style="width: 100%;">
        <h1 class="sudo">Transactions Table</h1>
            <div class="table-container" style="margin: 0 auto;">
                <table border="1" style=" margin: 20px 0;">
                    <thead>
                        <tr>
                            <th>S/N</th>
                            <th>Payment ID</th>
                            <th>Email</th>
                            <th>Course</th>
                            <th>Payment Method</th>
                            <th>Status</th>
                            <th>Price</th>
                            <th>Date</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                        $result = $connect->prepare("SELECT * FROM `payment`");
                        $result->execute();
                        $x = 1;

                        while ($row = $result->fetch(PDO::FETCH_ASSOC)){
                            $id = $row['payment_id'];
                            $email = $row['email'];
                            $price = $row['price'];
                            $method= $row['payment_method'];
                            $course = $row['course'];
                            $status = $row['status'];
                            $date = $row['date'];
                            ?>
                            <tr>
                                <td><?php echo $x; ?></td>
                                <td><?php echo $id; ?></td>
                                <td><?php echo $email; ?></td>
                                <td><?php echo $course; ?></td>
                                <td><?php echo $method; ?></td>
                                <td><?php echo $status; ?></td>
                                <td><?php echo $price; ?></td>
                                <td><?php echo $date; ?></td>
                                <td>
                                    <a style="color: #37030f; font-weight: bolder; color: #fff; padding: 2px 6px; border-radius: 50%; background-color:#890425;" href="handler/handler.php?del=<?php echo $id; ?>">&times;</a>
                                </td>
                            </tr>
                            <?php
                            $x++;
                        }
                    ?>
                    </tbody>
                </table>
            </div>
            <p style="margin: 0 auto; margin-top: 35px; text-align:center; width: 70%;">
                <a style="color: #ccc;" href="index.php">Back To Home</a>
            </p>
        </div>
    </body>
</html>