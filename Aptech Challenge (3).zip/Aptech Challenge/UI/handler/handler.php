<?php

/** REQUIRING THE CONFIG FILE **/
require_once ('../db/config.php');

/** WHEN THE USER CLICKS ON THE PAY BUTTON **/
if (isset($_POST['submit'])) {

    /** FILTERING THE POST ARRAY **/
    $POST = filter_var_array($_POST, FILTER_SANITIZE_STRING);

    /** COLLECTING VALUES FROM THE INPUTS AND STORING IT IN VARIABLES **/
    $email = $POST['email'];
    $course = trim($POST['course']);
    $price = $POST['price'];
    $status = "Pending";

    /** CHECKING IF THE USER HAVE ALREADY MADE SIMILAR PAYMENT **/
    $sql = "SELECT * FROM `payment` WHERE `email` = :email AND `course` = :course AND `status` = :status";
    $output = $connect->prepare($sql);
    $output->execute([
        'email' =>  $email,
        'course' => $course,
        'status' => 'Successful'
    ]);

    /** IF PAYMENT EXISTS REDIRECT THE USER BACK TO INDEX PAGE **/
    if ($output->rowCount() > 0) {
        header('location: ../pay-page.php?alert=exists');
    }

    /** ELSE STORE THE INPUT VALUES IN THE DATABASE **/
    else {
        $query = "INSERT INTO `payment`(`email`, `status`, `course`, `price`) VALUES(:email, :status, :course, :price)";
        $result = $connect->prepare($query);
        $result->execute([
            'email' => $email,
            'status' => $status,
            'course' => $course,
            'price' => $price
        ]);

        /** IF THE USER'S DATA WAS SUCCESSFULLY STORED IN THE DATABASE **/
        if ($result) {

            /** CREATE A SESSION {this will be used across various pages of the site} **/
            session_start();
            $_SESSION['email'] = $email;
            $_SESSION['course'] = $course;

            /** REDIRECT THE USER TO THE CHOOSE PAYMENT PAGE **/
            header('location: ../choose.php');
        }
        else {
            echo "something went wrong"; /** THIS WILL DISPLAY IF THERE WAS AN ERROR WHEN STORING THE USER'S DATA **/
        }
    }
}
/** --------------------------------------------   END OF PAY BUTTON FUNCTION ----------------------------------------------- **/


/** FOR THE CANCEL BUTTON **/
if (isset($_GET['cancel'])) {

    session_start();
    $email = $_SESSION['email'];
    $course = $_SESSION['course'];
    
    $id = '-----';
    $pay_method = '-----';

    $status = 'Cancelled';

    /** CHANGE THE STATUS **/
    $query = $connect->prepare("UPDATE `payment` SET `status` = :status, `payment_method` = :paymethod,  `payment_id` = :id WHERE `email` = :email AND `course` = :course");
    $query->execute([
        'paymethod' => $pay_method,
        'id' => $id,
        'status' => $status,
        'email' => $email,
        'course' => $course
    ]);

    /** IF SUCCESSFUL **/
    if ($query) {

        /** DESTROY THE SESSIONS, THEN REDIRECTED BACK TO PAY PAGE**/
        session_destroy();
    
        header('location: ../pay-page.php?alert=cancelled');
    }
}



/**  IF THE USER CLICKS ON THE PAYSTACK'S BUTTON  **/
if(isset($_GET['p_m'])){

    /** GET THE VALUES OF THOSE SESSION VARIABLES WE STORED IN THE PREVIOUS FUNCTION [lines 46 & 47 ] **/
    session_start();
    $method = 'paystack';
    $email = $_SESSION['email'];
    $course = $_SESSION['course'];

    /** UPDATE THE DATABASE, SET THE PAYMENT METHOD TO PAYSTACK WHERE THE EMAIL AND COURSE MATCHES THE ONE ON THE SESSION VARIABLES **/
    $result = $connect->prepare("UPDATE `payment` SET `payment_method` = :paymethod WHERE `email` = :email AND `course` = :course");
    $result->execute([
        'paymethod' => $method,
        'email' => $email,
        'course' => $course
    ]);

    /** IF IT WAS SUCCESSFUL **/
    if ($result) {

        /** CHECK THE COURSE THE USER IS PAYING FOR **/
        switch ($course){

            /** IF IT'S UI/UX THEN REDIRECT THE USER TO THE PAYSTACK'S UI/UX CREATED PAYMENT PAGE **/
            case 'UI/UX':
                header('location: https://paystack.com/pay/ui');
                break;

            /** IF IT'S WEB-DEV THEN REDIRECT THE USER TO THE PAYSTACK'S WEB-DEV CREATED PAYMENT PAGE **/
            case 'Web Development':
                header('location: https://paystack.com/pay/devweb');
                break;

            /** IF IT'S CCNA THEN REDIRECT THE USER TO THE PAYSTACK'S CCNA CREATED PAYMENT PAGE **/
            case 'CCNA':
                header('location: https://paystack.com/pay/ccna');
                break;
        }

    }
}
/** IF THE PAYMENT WAS SUCCESSFUL, PAYSTACK WILL REDIRECT THE USER TO THE SUCCESS PAGE WITH A REFERENCE ID**/


/** GET THE REFERENCE ID **/
if(isset($_GET['reference'])){
    $id = $_GET['reference'];

    /** SAME AS LINE 63 **/
    session_start();
    $email = $_SESSION['email'];
    $course = $_SESSION['course'];


    /** STATUS WILL BE UPDATED TO SUCCESSFUL **/
    $status = 'Successful';

    /** UPDATE THE DATABASE AGAIN, NOW SET THE PAYMENT ID TO THAT PAYSTACK'S REFERENCE ID AND THE STATUS TO SUCCESSFUL **/
    $result = $connect->prepare("UPDATE `payment` SET `payment_id` = :id, `status` = :status WHERE `email` = :email AND `course` = :course");
    $result->execute([
        'id' => $id,
        'status' => $status,
        'email' => $email,
        'course' => $course
    ]);

    /** IF IT WAS SUCCESSFULL **/
    if($result){

        /** DESTROY THOSE SESSIONS WE SET EARLIER ON LINES 46 & 47 **/
        session_start();
        session_destroy();

        /** REDIRECT THE USER BACK TO THE PAYMENT PAGE **/
        header('location: ../pay-page.php?alert=p_s');
    }
}


/**--------------------------------------     THE END        -----------------------------------------**/


/** JUST FOR THE TRANSACTION TABLE **/
if(isset($_GET['del'])){

    /** GET THE PAYMENT ID FROM THE $_GET VARIABLE **/
    $id = $_GET['del'];

    /** DELETE FROM THE DATABASE THE ROW WHERE THE PAYMENT ID MATCHES THE ONE IN THE $_GET VARIABLE **/
    $result = $connect->prepare("DELETE FROM `payment` WHERE `payment_id` = :id");
    $result->execute(['id' => $id]);

    if ($result){

        /** CLEAR ALL THE SESSIONS, IF ANY.. **/
        session_start();
        session_destroy();

        /** REDIRECT BACK TO THE TRANSACTIONS PAGE **/
        header('location: ../transactions.php?alert=del_s');
    }
}
