                    /*** TEAM OMEGA'S PROJECT ***/

##STEPS TO RUN THE PROJECT
##### Follow these easy steps

- Create a database named `portal`.

- Import the sql File `portal` in the portal database

- If in any case the `payment` table fails to create automatically, you'll have to create them manually.

- The `payment` table contains the following columns
 `payment_id` (PRIMARY KEY),
  `email`,
  `course`,
  `status`,
  `price`,
  `date` (DATETIME default CURRENT TIMESTAMP)
###### *You're all set up.*

##  HOW THE PROGRAM WORKS
- When the `Get Started` button is clicks in the landing page (index.php), it takes the user to the pay-page.php where he/she will fill the required pages.

- When the user is done filling the form and clicks on the `pay` button, the page sends the information gotten from the user to `handler.php`, the `handler.php` then store the infomation in the database, create session variables and then redirects the user to `choose.php`.

- In the `choose.php`, the user will select a payment method which in our case is PAYSTACK, when the user clicks on it, it calls the `handler.php` which then check the course the user wants to pay for (through those session that was set earlier) and then redirect the user to the appropriate PAYSTACK PAGE (manually created) where he/she will make the payment.

- After the user is done with the payment, paystack will redirect the user back to `success.php` with a `reference id` , the `success.php` contains a link `finish transaction` which also call the `handler.php`, the `handler.php` will take the `reference id` from the `success.php` and store it in the database where the users info was stored earlier,  and then redirect the user back to the `pay-page.php`.