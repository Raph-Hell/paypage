<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport"
              content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Team Omega</title>
        <link rel="stylesheet" href="css/extra.css">
        <script src="./js/team.js" defer></script>
        <link rel="shortcut icon" href="img/omega-logo-black-and-white.png" type="image/x-icon">
        <style>
            img{
                box-shadow: 2px 2px 10px 5px rgba(0, 0, 0, 0.2), -2px -2px 10px 5px rgba(0, 0, 0, 0.2);
            }
        </style>
    </head>
    <body>

        <h1 id="static">Team Omega
            <a class="back" href="index.php">&leftarrow;</a>
        </h1>
        <div class="faculty">
            <div class="inner">
                <img src="img/FB_IMG_16070224563454489-removebg-preview.png" alt="">
                <div class="details">
                    <h3>Enoch E. David</h3>
                    <p>Faculty <br> Head (OMEGA TEAM)</p>
                </div>
            </div>
        </div>

        <div class="lists">
            <div class="item">
                <img class="turn2" src="img/IMG_20200821_191428.jpg">
                <div class="details">
                    <h3>Victory E. Chukwu</h3>
                    <p>UI</p>
                </div>
            </div>

            <div class="item">
                <img src="img/bootstrap-icons/icons/person-fill.svg">
                <div class="details">
                    <h3>Mmasinachi Ezeruigbo</h3>
                    <p>UI</p>
                </div>
            </div>
        </div>

        <div class="lists">
            <div class="item">
                <img src="img/bootstrap-icons/icons/person-fill.svg">
                <div class="details">
                    <h3>Chibuchi D. Tagbo</h3>
                    <p>Front-End</p>
                </div>
            </div>

            <div class="item">
                <img class="turn" src="img/kosi.jpg">
                <div class="details">
                    <h3>Kaosiso Nwachukwu</h3>
                    <p>Front-End</p>
                </div>
            </div>

            <div class="item">
                <img class="turn" src="img/IMG-20201203-WA0007.jpg">
                <div class="details">
                    <h3>Rosario Onwuka</h3>
                    <p>Front-End</p>
                </div>
            </div>
        </div>

        <div class="lists">
            <div class="item">
                <img src="img/IMG-20201210-WA0003.jpg">
                <div class="details">
                    <h3>Stanley Precious</h3>
                    <p>Back-End</p>
                </div>
            </div>

            <div class="item">
                <img src="img/IMG_20200419_165215_111_2-removebg-preview.png">
                <div class="details">
                    <h3>Chidindu E. Aneke</h3>
                    <p>Back-End</p>
                </div>
            </div>

            <div class="item">
                <img src="img/IMG-20201208-WA0001-removebg-preview.png">
                <div class="details">
                    <h3>Chinedu Ezeruigbo</h3>
                    <p>Back-End</p>
                </div>
            </div>
        </div>
    </body>
</html>