<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport"
              content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Payment Page</title>
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/animate.min.css">
        <link rel="shortcut icon" href="img/omega-logo-black-and-white.png" type="image/x-icon">
        <script src="./js/landing.js" defer></script>
        <style>
            .notifier{
                position: absolute;
                bottom: -100%;
                padding: 12px 15px;
                width: 70%;
                display: flex;
                justify-content: space-between;
                align-items: center;
                background-color: rgba(94, 5, 26, .7); /*rgba(137, 4, 37, .7);*/
                left: 50%;
                transform: translateX(-50%);
                transition: all .9s ease-in-out;
            }
            .notifier p{
                width: 70%;
                font-size: .9rem;
            }
            .notifier .holder{
                width: 30%;
            }
            .holder a{
                padding: 10px 20px;
                background-color: #5E051A;
                border-radius: 4px;
                color: #fff;
                margin: 0 3px;
                transition: all .4s ease-in-out;
            }
            .holder a:hover{
                background-color: #890425;
            }
            .holder a:focus{
                background-color: #890425;
                border:none;
                outline: none;
            }
        </style>
    </head>
    <body id="landing">
        <div class="loader">
            <span class="span"></span>
        </div>

        <div  class="landing-page">
            <nav>
                <a style="position:relative;" href="#" class="logo">
                    <img src="img/favicon.ico" alt="aptech-logo">
                    <h2>Aptech
                        <span>Center</span>
                    </h2>
                </a>
                <div class="team">
                    <a style="clip-path: polygon(20% 0%, 100% 0, 100% 100%, 0% 100%);" href="extra.php">Team</a>
                </div>
            </nav>
            <main>
                <div class="container">
                    <h1 class="animate__animated animate__slideInLeft">WELCOME TO APTECH PAYMENT PORTAL</h1>
                    <p class="animate__animated animate__slideInLeft" style="font-size: 16px;">Our newly designed portal with improved interface and new courses addition has gone live.
                        <br> Click the button below to get started.
                    </p>
                    <div class="last">
                        <button id="lift" class="animate__animated animate__fadeIn animate__delay-1s">Get Started</button>
                    </div>
                </div>
            </main>
            <?php
                session_start();
                if(isset($_SESSION['email'])){
                    ?>
            <div class="notifier">
                <p>You have a pending transaction in your last session. Do you want to continue?</p>
                <div class="holder">
                    <a href="choose.php">Continue</a>
                    <a href="handler/handler.php?cancel">Cancel</a>
                </div>
            </div>
            <?php
                }
            ?>
            <div
        </div>
    </body>
</html>
