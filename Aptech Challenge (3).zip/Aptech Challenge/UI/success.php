<?php
require_once ('db/config.php');

session_start();
if(!isset($_SESSION['email'])){
    header('location: pay-page.php');
}

if(isset($_GET['reference'])){
    $id = $_GET['reference'];
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Payment Page</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="shortcut icon" href="img/omega-logo-black-and-white.png" type="image/x-icon">
    <script defer src="js/main.js"></script>
</head>
<body>
<div class="wrapper">
    <div class="center animate__animated animate__bounceIn">
        <div class="mid">
            <div class="success-box">
                <p><?php
                    if (isset($_SESSION['email'])){
                        echo $_SESSION['email'];
                    }
                    else{
                        echo '';
                    }
                    ?>
                </p>
                <h1>
                    <svg width="1em" height=".8em" viewBox="0 0 16 16" class="bi bi-check2-circle" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" d="M15.354 2.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3-3a.5.5 0 1 1 .708-.708L8 9.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                        <path fill-rule="evenodd" d="M8 2.5A5.5 5.5 0 1 0 13.5 8a.5.5 0 0 1 1 0 6.5 6.5 0 1 1-3.25-5.63.5.5 0 1 1-.5.865A5.472 5.472 0 0 0 8 2.5z"/>
                    </svg>
                </h1>
                <h3>Success</h3>
                <div class="link-holder animate__animated animate__tada animate__delay-1s">
                    <a href="handler/handler.php?reference=<?php echo $id; ?>">Finish Transaction</a>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>